var SinhVien = function (){
    this.MaSV = '';
    this.HoTen = '';
    this.Email = '';
    this.SoDT = '';
    this.CMND = '';
    this.DiemToan = '';
    this.DiemLy ='';
    this.DiemHoa = '';
}